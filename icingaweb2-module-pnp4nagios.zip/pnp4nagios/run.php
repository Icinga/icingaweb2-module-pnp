<?php

$this->registerHook('grapher', '\\Icinga\\Module\\Pnp4nagios\\Grapher');

