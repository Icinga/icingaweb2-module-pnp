<?php

$this->provideConfigTab('config', array(
    'title' => 'Configuration',
    'url' => 'config'
));

